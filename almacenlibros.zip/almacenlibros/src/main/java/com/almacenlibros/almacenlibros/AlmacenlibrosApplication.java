package com.almacenlibros.almacenlibros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmacenlibrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmacenlibrosApplication.class, args);
	}

}
